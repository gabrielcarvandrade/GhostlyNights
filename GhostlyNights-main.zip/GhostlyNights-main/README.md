# GhostlyNights
Projeto de IPOO, visando criar um jogo 2D na plataforma Greenfoot, aplicando estudos em JAVA
